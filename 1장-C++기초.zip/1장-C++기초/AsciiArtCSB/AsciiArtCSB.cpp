#include <iostream>

using namespace std;

int main() {

	cout << "  ___  ____  ____ \n";
	cout << " / __)/ ___)(  _ \\\n";
	cout << "( (__ \\___ \\ ) _ (\n";
	cout << " \\___)(____/(____/\n";




}