//��ü����
#include <stdio.h>
#include "GuguDan.h"

int GuguDan::GuguPrint() {
	

	for (int dan = 2; dan <= 9; dan += 4) {
		for (int i = 1; i <= 9; i++) {
			for (int j = 0; j < 4; j++) {
				printf("%2d x %2d = %2d\t", dan+j, i, (dan+j) * i);
			}
			printf("\n");
		}
		printf("\n");
	}
	return 0;
}

int main() {
	GuguDan gugu;
	gugu.GuguPrint();
}