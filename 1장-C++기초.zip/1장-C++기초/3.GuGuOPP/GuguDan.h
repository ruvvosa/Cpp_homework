class GuguDan {
public:
	int GuguPrint();
};